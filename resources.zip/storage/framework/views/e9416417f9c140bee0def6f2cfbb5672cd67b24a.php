<?php $__env->startSection('content'); ?>
<div id="app">
  <report :agro_id="<?php echo e($agrolytic->id); ?>" :user_id="<?php echo e(Auth::user()->id); ?>" :role="'<?php echo e(Auth::user()->type); ?>'"></report>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.vue_app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
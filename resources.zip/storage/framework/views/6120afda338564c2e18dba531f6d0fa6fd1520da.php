<?php $__env->startSection('content'); ?>
<div id="app">
  <agrolytic :user_id = "<?php echo e(Auth::user()->id); ?>" :role="'<?php echo e(Auth::user()->type); ?>'" :sec_id="<?php echo e(request()->input('sec_id',0)); ?>" :cat_id="<?php echo e(request()->input('cat_id',0)); ?>"></agrolytic>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.vue_app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
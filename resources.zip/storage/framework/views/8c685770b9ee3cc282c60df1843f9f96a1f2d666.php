<?php $__env->startSection('content'); ?>
<div id="app">
  <group></group>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.vue_app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
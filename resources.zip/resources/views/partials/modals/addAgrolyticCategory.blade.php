
<div class="modal" id="agrolyticCatModal"  role="dialog">
  <div class="modal-dialog modal-md" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Agrolytic Category</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>

      <div class="modal-body">
      	<form id="addCategoryForm" >
      	 
          <input type="text" name="name" id="name" class="form-control" >
          
      		<input type="hidden" name="type" value="addCategory">
      		<input type="hidden"  name="id" id="idCat" >
      	</form>
      </div>
      <div class="modal-footer">
      <button id="submitFormCategoryAssign" class="btn btn-success mr-2">Save</button>
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
         
      </div>
    </div>
  </div>
</div>

<!--  -->
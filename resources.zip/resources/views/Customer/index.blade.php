@extends('layouts.vue_app')

@section('content')
<div id="app">
  <customer></customer>
</div>
@endsection
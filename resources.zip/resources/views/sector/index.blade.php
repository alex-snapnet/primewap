@extends('layouts.vue_app')

@section('content')
<div id="app">
  <sector></sector>
</div>
@endsection
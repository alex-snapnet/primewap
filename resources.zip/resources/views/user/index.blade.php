@extends('layouts.vue_app')

@section('content')
<div id="app">
  <user></user>
</div>
@endsection
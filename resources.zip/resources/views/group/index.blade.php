@extends('layouts.vue_app')

@section('content')
<div id="app">
  <group></group>
</div>
@endsection
@extends('layouts.vue_app')

@section('content')
<div id="app">
  <category></category>
</div>
@endsection